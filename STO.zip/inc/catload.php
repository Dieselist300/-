<?php
    session_start();
    $group_id = $_POST['group'];
    $items = $_SESSION['items'];
    
    echo '<div class="main__item-container"><div class="main__items-list">';
    foreach ($items as $value) {
        if ($value[4] == $group_id)
        {
            echo '<div class="item">'
            . '<span class="item__name">' . $value[0] . " (" . $value[3]. ')' . '</span>'
            . '<span class="item__price">'. $value[1] .' руб</span>'
            . '<button class="item__add-button" value="'. $value[2] .'">Добавить</button>'
            .'</div>';
        }
        
    } 
        
    echo '</div></div>';