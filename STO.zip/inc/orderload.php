<?php
    session_start();

    require_once 'connect.php';
    $user = $_SESSION['user']['id'];
    
    $check_orders_id = $db->prepare(
        "SELECT `id`
        FROM `order_list` WHERE `user_id` = ?");
    $check_orders_id->bind_param("i", $user);
    $check_orders_id->execute();
    $check_orders_id = $check_orders_id->get_result();
    if (mysqli_num_rows($check_orders_id) > 0) {
        $orders = mysqli_fetch_all($check_orders_id ,MYSQLI_ASSOC);

        foreach ($orders as $value) {
            $check_order_id = $db->prepare("SELECT `work_id` FROM `list_for_order` WHERE `order_id` = ?");
            $check_order_id->bind_param('i', $value['id']);
            $check_order_id->execute();
            $check_order_id = $check_order_id->get_result();
            if (mysqli_num_rows($check_order_id) > 0) {
                echo '<h1>Заказ №'. $value['id'] .'</h1>';
                echo '<table class="stock_table">
                <thead>
                    <tr>
                        <th scope="col">Категория</th>
                        <th scope="col">Услуга</th>
                        <th scope="col">Цена</th>
                    </tr>
                </thead>
                <tbody">';
                
                $order = mysqli_fetch_all($check_order_id ,MYSQLI_ASSOC);
                $total = 0;
                foreach ($order as $v1) {
                    $chek_item = $db->prepare('SELECT category.name as category, `work`.`name`, `price` FROM `work` 
                    LEFT JOIN category on category.id = work.cat_id
                    WHERE work.id = ?');
                    $chek_item->bind_param('i', $v1['work_id']);
                    $chek_item->execute();
                    $chek_item = $chek_item->get_result();
                    $item = mysqli_fetch_assoc($chek_item);

                     echo '<tr>'
                            . '<td>' . $item['category'] . '</td>'
                            . '<td>' . $item['name'] . '</td>'
                            . '<td>' . $item['price'] . '</td>'
                            . '</tr>';
                    $total += $item['price'];
                }
                echo '</tbody>
                <tfoot>
                    <tr>
                    <th scope="row" colspan="2">Итого: </th>
                    <td colspan="2">'. $total .'</td>
                    </tr>
                </tfoot>
                </table>';
            } else {echo '<h1>Ошибка</h1>';}

        }
        echo '</tbody>
        </table>';
    }
    else
    {
        echo '<h1>Не удалось загрузить работы</h1>';
    }