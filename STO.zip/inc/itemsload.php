<?php
    
    require_once 'connect.php';
    session_start();
    $check_items = $db->prepare(
        "SELECT work.name,
        price,
        work.id,
        category.name,
        cat_id
        FROM work
        LEFT JOIN category on category.id = work.cat_id");
    $check_items->execute();
    $check_items = $check_items->get_result();
    
    if (mysqli_num_rows($check_items) > 0) {
        $data = mysqli_fetch_all($check_items);
        echo '<div class="main__item-container"><div class="main__items-list">';
        foreach ($data as $value) {
            echo '<div class="item">'
            . '<span class="item__name">' . $value[0] . " (" . $value[3]. ')' . '</span>'
            . '<span class="item__price">'. $value[1] .' руб</span>'
            . '<button class="item__add-button" value="'. $value[2] .'">Добавить</button>'
            .'</div>';
        }
        echo '</div></div>';
        
        $_SESSION['items'] = $data;
    }
    else {
        $_SESSION['message'] = 'Услуги не найдены';
    }

